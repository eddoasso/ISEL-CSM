import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
from time import time
import urllib

urllib.request.urlretrieve("https://homepages.cae.wisc.edu/~ece533/images/lena.bmp","lena.bmp")